import csv
import torch as t
import numpy as np
from PIL import Image
from torch.utils import data
from torchvision import transforms as T

class DigitalData(data.Dataset):
    def __init__(self, root, transforms=None, train=True, test=False):
        '''
        目标：读取数据，并根据训练，验证，测试划分数据
        '''
        self.test = test
        f = open(root, 'r')
        reader = list(csv.reader(f))[1:]
        length = len(reader)
        if self.test:
            self.imgs = np.array(reader).reshape(length, 28, 28)
        elif train:
            self.imgs = reader[:int(0.7*length)]
        else:
            self.imgs = reader[int(0.7*length):]
        f.close()
        
        if transforms is None:
            self.transform = T.Compose([
                T.ToTensor()
            ])
            
    def __getitem__(self, index):
        '''
        返回一张图片的像素数据和id
        若是测试集则没有id，返回的是像素数据和-1
        '''
        if self.test:
            data = Image.fromarray(self.imgs[index].astype('uint8')).convert('L')
            data = self.transform(data)
            return data, index+1
        else:
            label = self.imgs[index][0]
            data = np.array(self.imgs[index][1:]).reshape(28, 28)
            data = Image.fromarray(data.astype('uint8')).convert('L')
            data = self.transform(data)
            return data, label
        
    def __len__(self):
        '''
        返回数据集中所有图片的个数
        '''
        return len(self.imgs)